package common.contract;


import java.util.List;

/**
 * @author imseongbin
 * @version 1.0
 * @created 01-5-2023 ?? 4:49:58
 */
public class ContractListImpl implements ContractList {

	private List<Contract> contractList;
	public Contract contract;

	public ContractListImpl(){

	}

	public void finalize() throws Throwable {

	}

	/**
	 * 
	 * @param contract
	 */
	public void add(Contract contract){

	}

	/**
	 * 
	 * @param id
	 */
	public void delete(int id){

	}

	/**
	 * 
	 * @param id
	 */
	public void retrieve(int id){

	}

	/**
	 * 
	 * @param contract
	 */
	public void update(Contract contract){

	}

}