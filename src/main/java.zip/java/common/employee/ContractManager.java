package common.employee;

public class ContractManager extends Employee{

	
	private static final long serialVersionUID = 1L;

	public ContractManager(String[] values) {
		super(values);
	}

}
