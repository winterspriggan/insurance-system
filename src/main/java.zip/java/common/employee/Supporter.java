package common.employee;

public class Supporter extends Employee {
    public Supporter(String[] values) {
        super(values);
    }
}
