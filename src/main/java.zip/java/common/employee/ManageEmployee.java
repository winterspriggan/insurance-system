package common.employee;


import common.employee.Employee;

/**
 * @author LG
 * @version 1.0
 * @created 01-5-2023 ?? 4:50:00
 */
public class ManageEmployee extends Employee {


    public ManageEmployee(String[] values) {
        super(values);
    }

    public void finalize() throws Throwable {
        super.finalize();
    }

}