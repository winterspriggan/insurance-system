package common.employee;

public class Developer extends Employee{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public Developer(String[] values) {
		super(values);
	}
}
