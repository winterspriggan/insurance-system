package contract;


/**
 * @author junse
 * @version 1.0
 * @created 01-5-2023 ?? 4:50:00
 */
public class Underwriter {

	public Underwriter(){

	}

	public void finalize() throws Throwable {

	}

}