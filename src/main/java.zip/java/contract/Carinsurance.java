package contract;


/**
 * @author junse
 * @version 1.0
 * @created 01-5-2023 ?? 4:49:57
 */
public class Carinsurance extends Insurance {

	public Carinsurance(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}