package contract;


/**
 * @author junse
 * @version 1.0
 * @created 01-5-2023 ?? 4:49:59
 */
public class Insurance {

	public Insurance(){

	}

	public void finalize() throws Throwable {

	}

}